# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'

hello <- function() {
  print("Hello, world!")
}

#' Remove rows with Na Values from dataframe
#'
#' The function will remove all rows which contain na values.
#' Specific columns can be cleaned whilst ignoring the other columns
#' @param dataframe
#' a dataframe
#' @param applicableColumns
#' a vector of dataframe names which should be checked, ignore others
#' @return The dataframe with rows which have NA values removed
#' @examples
#' removeNaRows(data)
#' removeNaRows(read.csv("train.csv"))
#' removeNaRows(data, c("A", "B", "C"))
#' @export
removeNaRows <- function(dataframe, applicableColumns=c()) {
  if (length(applicableColumns)==0) {
    isNa <- is.na(dataframe)
  } else {
    isNa <- is.na(dataframe[, applicableColumns])
  }
  rowsWithoutNa <- rowSums(isNa) == 0
  dataframe[rowsWithoutNa, ]
}
